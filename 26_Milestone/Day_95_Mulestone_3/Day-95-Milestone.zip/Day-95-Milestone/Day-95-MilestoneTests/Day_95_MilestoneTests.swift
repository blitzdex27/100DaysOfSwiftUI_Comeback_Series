//
//  Day_95_MilestoneTests.swift
//  Day-95-MilestoneTests
//
//  Created by Dexter Ramos on 2/14/25.
//

import Testing
@testable import Day_95_Milestone

struct Day_95_MilestoneTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
