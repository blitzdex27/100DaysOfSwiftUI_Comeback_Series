//
//  Results.swift
//  Day-95-Milestone
//
//  Created by Dexter Ramos on 2/18/25.
//

import Foundation

class Results {
    var resul
}
